#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import tk.tk_sdk as tk_sdk

__all__ = ["tk_sdk"]
