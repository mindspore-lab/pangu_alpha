#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

from tk.src.security.param_check.option_check_utils import PathContentBlacklistCharactersCheck, AbsolutePathCheck, \
    PathExistCheck, LinkPathCheck, PathContentLengthCheck, PathContentCharacterCheck, PathGranularityCheck, \
    PathRightEscalationCheck, FileSizeCheck, DiskFreeSpaceCheck, get_real_path
from tk.src.utils.exceptions import FileOversizeError, LinkPathError, LowDiskFreeSizeRiskError
from tk.src.utils.constants import GB_SIZE


class FinetuneOptionsCheckParam:
    def __init__(self, path_length_check_param, path_content_check_param, mode, path_including_file, force_quit,
                 quiet):
        """
        微调入参校验参数
        :param path_length_check_param: 路径长度校验参数
        :param path_content_check_param: 路径内容校验参数
        :param mode: 路径权限范围约束
        :param path_including_file: 路径是否为文件路径
        :param force_quit: SDK场景下, 路径权限提升校验异常时是否强制退出
        :param quiet: CLI场景下，路径权限提升校验是否忽略交互式过程
        """
        self.path_length_check_param = path_length_check_param
        self.path_content_check_param = path_content_check_param
        self.mode = mode
        self.path_including_file = path_including_file
        self.force_quit = force_quit
        self.quiet = quiet


class FinetuneOptionsCheck:
    def __init__(self, option_name, option_value, disk_space_check=False):
        self.option_name = option_name
        self.option_value = option_value
        self.disk_space_check = disk_space_check
        self.is_valid = False

    def check(self, check_param):
        """
        微调入参校验
        :param check_param: 微调入参校验参数
        """
        # 针对原始路径进行的校验
        try:
            self._origin_path_check_item()
        except (ValueError, FileNotFoundError, LinkPathError) as ex:
            raise ex

        # 获取真实路径
        try:
            self.option_value = get_real_path(self.option_value)
        except ValueError as ex:
            raise ex

        # 针对真实路径进行的校验
        try:
            self._real_path_check_item(check_param)
        except (ValueError, PermissionError, FileOversizeError) as ex:
            raise ex

        self.is_valid = True

    def _origin_path_check_item(self):
        # 路径内容黑名单校验
        try:
            PathContentBlacklistCharactersCheck(option_name=self.option_name, option_value=self.option_value)
        except ValueError as ex:
            raise ex

        # 绝对路径校验
        try:
            AbsolutePathCheck(option_name=self.option_name, option_value=self.option_value)
        except ValueError as ex:
            raise ex

        # 路径真实性校验
        try:
            PathExistCheck(option_name=self.option_name, option_value=self.option_value)
        except FileNotFoundError as ex:
            raise ex

        # 路径软链接校验
        try:
            LinkPathCheck(option_name=self.option_name, option_value=self.option_value)
        except LinkPathError as ex:
            raise ex

    def _real_path_check_item(self, check_param):
        # 路径长度校验
        try:
            PathContentLengthCheck(option_name=self.option_name, option_value=self.option_value,
                                   path_min_limit=check_param.path_length_check_param.path_min_limit,
                                   path_max_limit=check_param.path_length_check_param.path_max_limit,
                                   file_min_limit=check_param.path_length_check_param.file_min_limit,
                                   file_max_limit=check_param.path_length_check_param.file_max_limit)
        except ValueError as ex:
            raise ex

        # 路径内容白名单校验
        try:
            PathContentCharacterCheck(option_name=self.option_name, option_value=self.option_value,
                                      base_whitelist_mode=check_param.path_content_check_param.base_whitelist_mode,
                                      extra_whitelist=check_param.path_content_check_param.extra_whitelist)
        except ValueError as ex:
            raise ex

        # 路径粒度校验
        try:
            PathGranularityCheck(option_name=self.option_name, option_value=self.option_value,
                                 path_including_file=check_param.path_including_file)
        except ValueError as ex:
            raise ex

        # 路径权限提升校验
        try:
            PathRightEscalationCheck(option_name=self.option_name, option_value=self.option_value,
                                     mode=check_param.mode,
                                     force_quit=check_param.force_quit,
                                     quiet=check_param.quiet)
        except (PermissionError, ValueError) as ex:
            raise ex

        # 路径文件大小校验
        try:
            FileSizeCheck(option_name=self.option_name, option_value=self.option_value,
                          path_including_file=check_param.path_including_file)
        except FileOversizeError as ex:
            raise ex

        # 路径所在磁盘空间耗尽风险校验
        if self.disk_space_check:
            try:
                DiskFreeSpaceCheck(option_name=self.option_name,
                                   option_value=self.option_value,
                                   free_space_limit=GB_SIZE,
                                   force_quit=check_param.force_quit,
                                   quiet=check_param.quiet)
            except (LowDiskFreeSizeRiskError, ValueError) as ex:
                raise ex
