#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

from tk.src.security.param_check.option_check_utils import PathExistCheck, LinkPathCheck, PathRightEscalationCheck, \
    FileSizeCheck, get_real_path
from tk.src.utils.exceptions import FileOversizeError, LinkPathError


class EvaluateResultFileCheckParam:
    def __init__(self, path_content_check_param, mode, path_including_file, force_quit, quiet):
        """
        微调入参校验参数
        :param path_content_check_param: 路径内容校验参数
        :param mode: 路径权限范围约束
        :param path_including_file: 路径是否为文件路径
        :param force_quit: SDK场景下, 路径权限提升校验异常时是否强制退出
        """
        self.path_content_check_param = path_content_check_param
        self.mode = mode
        self.path_including_file = path_including_file
        self.force_quit = force_quit
        self.quiet = quiet


class EvaluateResultCheck:
    def __init__(self, option_name, option_value):
        self.option_name = option_name
        self.option_value = option_value
        self.is_valid = False

    def check(self, check_param):
        """
        评估入参校验
        :param check_param: 评估入参校验参数
        """
        # 针对原始路径进行的校验
        try:
            self._origin_path_check_item()
        except (FileNotFoundError, LinkPathError) as ex:
            raise ex

        # 获取真实路径
        try:
            self.option_value = get_real_path(self.option_value)
        except ValueError as ex:
            raise ex

        # 针对真实路径进行的校验
        try:
            self._real_path_check_item(check_param)
        except (PermissionError, ValueError, FileOversizeError) as ex:
            raise ex

        self.is_valid = True

    def _origin_path_check_item(self):
        # 路径真实性校验
        try:
            PathExistCheck(option_name=self.option_name, option_value=self.option_value)
        except FileNotFoundError as ex:
            raise ex

        # 路径软链接校验
        try:
            LinkPathCheck(option_name=self.option_name, option_value=self.option_value)
        except LinkPathError as ex:
            raise ex

    def _real_path_check_item(self, check_param):
        # 路径权限提升校验
        try:
            PathRightEscalationCheck(option_name=self.option_name, option_value=self.option_value,
                                     mode=check_param.mode,
                                     force_quit=check_param.force_quit,
                                     quiet=check_param.quiet)
        except (PermissionError, ValueError) as ex:
            raise ex

        # 路径文件大小校验
        try:
            FileSizeCheck(option_name=self.option_name, option_value=self.option_value,
                          path_including_file=check_param.path_including_file)
        except FileOversizeError as ex:
            raise ex
