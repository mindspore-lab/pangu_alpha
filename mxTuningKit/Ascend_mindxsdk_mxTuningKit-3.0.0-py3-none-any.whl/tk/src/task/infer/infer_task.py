#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import os
import subprocess

from tk.src.utils.constants import MODEL_CONFIG_ROOT_KEYS, INFER_RESULT_FILE_NAME, SPACE_CHARACTER, PATH_MODE_LIMIT
from tk.src.utils.io_utils import read_file, read_json_file
from tk.src.utils.exceptions import LinkPathError, SubprocessError, FileOversizeError, MakeDirError
from tk.src.utils.task_utils import create_output_path_subdir_with_uuid, params_config_check_item, \
    monitor_process_rsp_code, config_key_check_item, check_in_out_loop
from tk.src.task.evaluate.evaluate_result_check import EvaluateResultFileCheckParam, EvaluateResultCheck
from tk.src.security.param_check.option_check_utils import PathContentCheckParam
from tk.src.log.log import logger, record_operation_and_service_error_log, \
    record_operation_and_service_info_log


class InferTask:
    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        self.command = []
        self.command_params = []

        try:
            self._process_param_and_command()
        except (AttributeError, FileNotFoundError, PermissionError, ValueError, LinkPathError) as ex:
            record_operation_and_service_error_log('infer failed.')
            raise ex
        except KeyboardInterrupt as ex:
            record_operation_and_service_error_log(
                'infer task is terminated by current user, task has stopped and exited.')
            raise ex

    def start(self):
        """
        启动命令
        :return: json串形式的推理结果
        """
        if not self.command:
            logger.error('command is empty, execute [process] before [start].')
            raise ValueError

        # 等待推理进程完成，落盘推理结果infer_result.json
        record_operation_and_service_info_log('inference task is running.')

        try:
            process = subprocess.Popen(self.command, env=os.environ, shell=False,
                                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except Exception as ex:
            logger.error('exception occurred when creating task process.')
            raise ex
        except KeyboardInterrupt as ex:
            record_operation_and_service_error_log(
                'infer task is terminated by current user, task has stopped and exited.')
            raise ex

        try:
            rsp_code = monitor_process_rsp_code(task_name='infer', task_process=process,
                                                timeout=self.kwargs.get('timeout'))
        except Exception as ex:
            logger.error('exception occurred when monitoring task process.')
            raise ex
        except KeyboardInterrupt as ex:
            record_operation_and_service_error_log(
                'infer task is terminated by current user, task has stopped and exited.')
            raise ex

        if rsp_code != 0:
            record_operation_and_service_error_log('infer failed.')
            raise SubprocessError

        # 校验用户代码生成的推理结果文件合法性
        full_output_path = self.command_params[self.command_params.index('--output_path') + 1]
        infer_result_path = os.path.join(full_output_path, INFER_RESULT_FILE_NAME)

        try:
            self._check_infer_result(infer_result_path)
        except (ValueError, PermissionError, FileOversizeError, LinkPathError, FileNotFoundError) as ex:
            raise ex

        # 读取并解析推理结果, 以json串形式并返回
        try:
            infer_result = read_json_file(infer_result_path)
        except (FileNotFoundError, LinkPathError, ValueError, TypeError) as ex:
            logger.error('exception occurred when reading the destination file content from [output_path].')
            record_operation_and_service_error_log('infer failed.')
            raise SubprocessError from ex

        record_operation_and_service_info_log('infer successfully.')
        return infer_result

    def _process_param_and_command(self):
        """
        推理任务启动前的准备工作
        """
        # 命令行参数准备
        try:
            self._prepare_command_params()
        except (AttributeError, FileNotFoundError, PermissionError, ValueError, LinkPathError) as ex:
            raise ex

        # 命令准备
        self._prepare_command()

    def _check_infer_result(self, eval_result_path):
        """
        校验推理结果文件合法性
        :return: None
        """
        base_whitelist_mode = 'ALL'
        extra_whitelist = ['.', '/', '-', '_', SPACE_CHARACTER]

        infer_result_file_path = EvaluateResultCheck(option_name='infer_result', option_value=eval_result_path)

        path_content_check_param = PathContentCheckParam(base_whitelist_mode=base_whitelist_mode,
                                                         extra_whitelist=extra_whitelist)

        check_param = EvaluateResultFileCheckParam(path_content_check_param=path_content_check_param,
                                                   mode=PATH_MODE_LIMIT,
                                                   path_including_file=True,
                                                   force_quit=False,
                                                   quiet=self.kwargs.get('quiet'))

        try:
            infer_result_file_path.check(check_param)
        except (ValueError, PermissionError, FileOversizeError, LinkPathError, FileNotFoundError) as ex:
            raise ex

        if not infer_result_file_path.is_valid:
            logger.error('invalid path: [infer_result_file_path], check settings.')
            raise ValueError

    def _prepare_command_params(self):
        """
        准备命令行参数
        """

        # 输入、输出回环路径判断
        try:
            check_in_out_loop(self.kwargs)
        except (ValueError, TypeError) as ex:
            logger.error('[output_path] cannot be the same as, or a subpath of the other input paths.')
            raise ex

        try:
            self._wrap_model_config_params()
        except (AttributeError, FileNotFoundError, ValueError, LinkPathError) as ex:
            raise ex

        try:
            self._wrap_required_params()
        except PermissionError as ex:
            raise ex

    def _wrap_required_params(self):
        """
        组装必填参数
        """
        try:
            output_path = create_output_path_subdir_with_uuid(self.kwargs.get('output_path'))
        except MakeDirError as ex:
            raise ex

        self.command_params.extend(['--output_path', output_path])
        self.command_params.extend(['--data_path', self.kwargs.get('data_path')])
        self.command_params.extend(['--ckpt_path', self.kwargs.get('ckpt_path')])

    def _wrap_model_config_params(self):
        """
        针对model_config配置文件内容，组装相关参数
        """
        model_config_option = self.kwargs.get('model_config_path')

        if model_config_option is not None:
            try:
                content = read_file(model_config_option)
            except Exception as ex:
                logger.error('exception occurred when reading file content from param: [model_config_path].')
                raise ex

            try:
                config_key_check_item(content, MODEL_CONFIG_ROOT_KEYS[0])
            except (AttributeError, ValueError) as ex:
                raise ex

            try:
                params_config_check_item(content=content, option_object=self)
            except ValueError as ex:
                raise ex

    def _prepare_command(self):
        """
        组装命令
        """
        self.command.append('python')
        self.command.append(self.kwargs.get('boot_file_path'))
        self.command.extend(self.command_params)
