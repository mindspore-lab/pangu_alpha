#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import os
import click

from tk.src.log.log import logger
from tk.src.task.finetune.finetune_options_check import FinetuneOptionsCheckParam, FinetuneOptionsCheck
from tk.src.security.param_check.option_check_utils import PathLengthCheckParam, PathContentCheckParam
from tk.src.utils.constants import SPACE_CHARACTER, DEFAULT_PATH_LEN_MIN_LIMIT, DEFAULT_PATH_LEN_MAX_LIMIT, \
    DEFAULT_FILE_LEN_MIN_LIMIT, DEFAULT_FILE_LEN_MAX_LIMIT, PATH_MODE_LIMIT
from tk.src.utils.exceptions import FileOversizeError, LinkPathError


class BootFilePathOption(click.core.Option):
    def __init__(self):
        super().__init__(
            param_decls=('-bp', '--boot_file_path'),
            type=str,
            help='boot file local path',
            callback=self.boot_file_path_callback
        )

    @staticmethod
    def _is_py_file(path):
        """
        路径是否是python文件

        :param path: 指定路径
        :return: 路径是否是python文件
        """
        return os.path.isfile(path) and path.endswith('.py')

    def boot_file_path_callback(self, ctx, param, value):
        """
        boot_file_path参数click回调方法

        :param ctx: 上下文信息
        :param param: 参数属性
        :param value: 输入值
        :return: 回调处理后的参数值
        """
        if value is None:
            logger.error('param: [boot_file_path] is required.')
            raise ValueError

        base_whitelist_mode = 'ALL'
        extra_whitelist = ['.', '/', '-', '_', SPACE_CHARACTER]

        boot_file_path_option = FinetuneOptionsCheck(option_name=param.name, option_value=value)

        path_length_check_param = PathLengthCheckParam(path_min_limit=DEFAULT_PATH_LEN_MIN_LIMIT,
                                                       path_max_limit=DEFAULT_PATH_LEN_MAX_LIMIT,
                                                       file_min_limit=DEFAULT_FILE_LEN_MIN_LIMIT,
                                                       file_max_limit=DEFAULT_FILE_LEN_MAX_LIMIT)

        path_content_check_param = PathContentCheckParam(base_whitelist_mode=base_whitelist_mode,
                                                         extra_whitelist=extra_whitelist)

        check_param = FinetuneOptionsCheckParam(path_length_check_param=path_length_check_param,
                                                path_content_check_param=path_content_check_param,
                                                mode=PATH_MODE_LIMIT,
                                                path_including_file=True,
                                                force_quit=True,
                                                quiet=ctx.params.get('quiet'))

        try:
            boot_file_path_option.check(check_param)
        except (ValueError, FileNotFoundError, PermissionError, FileOversizeError, LinkPathError) as ex:
            raise ex

        if not boot_file_path_option.is_valid:
            logger.error('invalid param: [boot_file_path], check settings.')
            raise ValueError

        if not self._is_py_file(boot_file_path_option.option_value):
            logger.error('param: [boot_file_path] only support .py file path.')
            raise ValueError

        return boot_file_path_option.option_value
