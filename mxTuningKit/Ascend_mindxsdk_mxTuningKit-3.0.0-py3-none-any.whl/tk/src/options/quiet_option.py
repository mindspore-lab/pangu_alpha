#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import click

from tk.src.log.log import logger


class QuietOption(click.core.Option):
    def __init__(self):
        super().__init__(
            param_decls=('-q', '--quiet'),
            type=bool,
            is_flag=True,
            help='enable quiet mode, ignore the risk of permission rules of incoming parameters.',
            callback=self.quiet_callback
        )

    def quiet_callback(self, ctx, params, value):
        if value is None:
            return value

        # --quiet参数仅允许被定义在首位, 其ctx上下文属性必须为空
        if value is True and ctx.params:
            logger.error('param [--quiet] should be set first.')
            raise ValueError

        return value
