#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import click

from tk.src.task.finetune.finetune_options_check import FinetuneOptionsCheckParam, FinetuneOptionsCheck
from tk.src.security.param_check.option_check_utils import PathLengthCheckParam, PathContentCheckParam
from tk.src.utils.constants import SPACE_CHARACTER, DEFAULT_PATH_LEN_MIN_LIMIT, DEFAULT_PATH_LEN_MAX_LIMIT, \
    DEFAULT_FILE_LEN_MIN_LIMIT, DEFAULT_FILE_LEN_MAX_LIMIT, PATH_MODE_LIMIT
from tk.src.utils.exceptions import FileOversizeError, LinkPathError
from tk.src.log.log import logger


class ModelConfigPathOption(click.core.Option):
    def __init__(self):
        super().__init__(
            param_decls=('-mc', '--model_config_path'),
            type=str,
            default=None,
            show_default=True,
            help='model config file local path',
            callback=self.model_config_path_callback
        )

    @staticmethod
    def _is_yaml_file(path):
        """
        路径是否是yaml文件
        :param path: 指定路径
        :return: 路径是否是yaml文件
        """
        return path.endswith('.yaml') or path.endswith('.yml')

    def model_config_path_callback(self, ctx, param, value):
        """
        model_config_path参数click回调方法

        :param ctx: 上下文信息
        :param param: 参数属性
        :param value: 输入值
        :return: 回调处理后的参数值
        """
        if value is None:
            return value

        base_whitelist_mode = 'ALL'
        extra_whitelist = ['.', '/', '-', '_', SPACE_CHARACTER]

        model_config_path = FinetuneOptionsCheck(option_name=param.name, option_value=value)

        path_length_check_param = PathLengthCheckParam(path_min_limit=DEFAULT_PATH_LEN_MIN_LIMIT,
                                                       path_max_limit=DEFAULT_PATH_LEN_MAX_LIMIT,
                                                       file_min_limit=DEFAULT_FILE_LEN_MIN_LIMIT,
                                                       file_max_limit=DEFAULT_FILE_LEN_MAX_LIMIT)

        path_content_check_param = PathContentCheckParam(base_whitelist_mode=base_whitelist_mode,
                                                         extra_whitelist=extra_whitelist)

        check_param = FinetuneOptionsCheckParam(path_length_check_param=path_length_check_param,
                                                path_content_check_param=path_content_check_param,
                                                mode=PATH_MODE_LIMIT,
                                                path_including_file=True,
                                                force_quit=False,
                                                quiet=ctx.params.get('quiet'))

        try:
            model_config_path.check(check_param)
        except (ValueError, FileNotFoundError, PermissionError, FileOversizeError, LinkPathError) as ex:
            raise ex

        if not model_config_path.is_valid:
            logger.error('invalid param: [model_config_path], check settings.')
            raise ValueError

        if not self._is_yaml_file(model_config_path.option_value):
            logger.error('param: [model_config_path] only support .yaml or .yml file path.')
            raise ValueError

        return model_config_path.option_value
