#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import click

from tk.src.task.finetune.finetune_options_check import FinetuneOptionsCheckParam, FinetuneOptionsCheck
from tk.src.security.param_check.option_check_utils import PathLengthCheckParam, PathContentCheckParam
from tk.src.utils.constants import SPACE_CHARACTER, DEFAULT_PATH_LEN_MIN_LIMIT, DEFAULT_PATH_LEN_MAX_LIMIT, \
    PATH_MODE_LIMIT
from tk.src.utils.exceptions import FileOversizeError, LinkPathError
from tk.src.log.log import logger


class OutputPathOption(click.core.Option):
    def __init__(self):
        super().__init__(
            param_decls=('-op', '--output_path'),
            type=str,
            help='output local path',
            callback=self.output_path_callback
        )

    def output_path_callback(self, ctx, param, value):
        """
        output_path参数click回调方法

        :param ctx: 上下文信息
        :param param: 参数属性
        :param value: 输入值
        :return: 回调处理后的参数值
        """
        if value is None:
            logger.error('param: [output_path] is required.')
            raise ValueError

        base_whitelist_mode = 'ALL'
        extra_whitelist = ['/', '-', '_', SPACE_CHARACTER]

        output_path_option = FinetuneOptionsCheck(option_name=param.name, option_value=value, disk_space_check=True)

        path_length_check_param = PathLengthCheckParam(path_min_limit=DEFAULT_PATH_LEN_MIN_LIMIT,
                                                       path_max_limit=DEFAULT_PATH_LEN_MAX_LIMIT,
                                                       file_min_limit=None,
                                                       file_max_limit=None)

        path_content_check_param = PathContentCheckParam(base_whitelist_mode=base_whitelist_mode,
                                                         extra_whitelist=extra_whitelist)

        check_param = FinetuneOptionsCheckParam(path_length_check_param=path_length_check_param,
                                                path_content_check_param=path_content_check_param,
                                                mode=PATH_MODE_LIMIT,
                                                path_including_file=False,
                                                force_quit=False,
                                                quiet=ctx.params.get('quiet'))

        try:
            output_path_option.check(check_param)
        except (ValueError, FileNotFoundError, PermissionError, FileOversizeError, LinkPathError) as ex:
            raise ex

        if not output_path_option.is_valid:
            logger.error('invalid param: [output_path], check settings.')
            raise ValueError

        return output_path_option.option_value
