#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

from tk.src.log.log import logger
from tk.src.utils.constants import MODEL_CONFIG_CHARACTER_BLACKLIST, FREEZE_CONFIG_CONNECTED_WITH, \
    MODEL_CONFIG_LEN_LIMIT


class ModelConfigCheck:
    def __init__(self, params_config=None, freeze_config=None):
        self.params = params_config
        self.freeze = freeze_config
        self.is_valid = False

        if self.params is None and self.freeze is None:
            logger.error('params_config/freeze_config is required.')
            raise ValueError

        if self.params is not None and not isinstance(self.params, dict):
            logger.error('The params_config is invalid, which must be key-value pairs')
            raise ValueError

        if self.freeze is not None and not isinstance(self.freeze, (dict, str)):
            logger.error('The freeze_config is invalid, which must be key-value pairs or single string.')
            raise ValueError

    @staticmethod
    def split_vals_with_same_key(expanded_dict):
        """
        对同一前缀下的多个子名称进行拆分
        :param expanded_dict: 平铺后的字典
        :return: 拆分后的完整名称列表
        """
        res = []
        for key_item, val_item in expanded_dict.items():
            for val in val_item:
                res.append(f'{str(key_item)}{FREEZE_CONFIG_CONNECTED_WITH}{str(val)}')
        return res

    @staticmethod
    def get_prefix_dict(dict_info, prefix_str):
        """
        获取包含前缀字典(多层嵌套使用)
        :param dict_info: 配置字典
        :param prefix_str: 前缀信息
        :return: 拼接前缀后的字典
        """
        return {prefix_str + FREEZE_CONFIG_CONNECTED_WITH + str(k): v for k, v in dict_info.items()}

    def check(self):
        try:
            self._params_config_check()
        except ValueError as ex:
            raise ex

        try:
            self._freeze_config_check()
        except ValueError as ex:
            raise ex

        self.is_valid = True

    def _params_config_check(self):
        """
        model config配置文件params部分参数黑名单校验
        """
        if self.params is None:
            return

        for param in self.params.items():
            param_key, param_val = param[0], param[1]

            if param_key is None or param_val is None:
                logger.error('config info in [params] part is empty.')
                raise ValueError

            # 判断 params 的 value 部分是否为单层键值对
            if isinstance(param_val, dict):
                logger.error('config info in [params] part only support single-level nesting.')
                raise ValueError

            param_key, param_val = str(param_key), str(param_val)

            if len(param_key) > MODEL_CONFIG_LEN_LIMIT or len(param_val) > MODEL_CONFIG_LEN_LIMIT:
                logger.error('config info in [params] part is too long.')
                raise ValueError

            for k_item in param_key:
                if k_item in MODEL_CONFIG_CHARACTER_BLACKLIST:
                    logger.error('invalid character in [params] part from model config file.')
                    raise ValueError

            for v_item in param_val:
                if v_item in MODEL_CONFIG_CHARACTER_BLACKLIST:
                    logger.error('invalid character in [params] part from model config file.')
                    raise ValueError

    def _freeze_config_check(self):
        """
        model config配置文件freeze部分参数黑名单校验
        """
        if self.freeze is None:
            return

        freeze_configs = self._get_freeze_config()
        if not freeze_configs:
            return

        for freeze in freeze_configs:
            if len(freeze) > MODEL_CONFIG_LEN_LIMIT:
                logger.error('config info in [freeze] part is too long.')
                raise ValueError

            for item in freeze:
                if item in MODEL_CONFIG_CHARACTER_BLACKLIST:
                    logger.error('invalid character in [freeze] part from model config file.')
                    raise ValueError

    def _get_freeze_config(self):
        """
        按层级解析freeze参数, 拼接成完整名称
        :return: freeze配置名称集合
        """
        if self.freeze is None:
            return []

        if isinstance(self.freeze, str):
            return [self.freeze]

        expanded_dict = self._expand_dict(self.freeze)
        ret = self.split_vals_with_same_key(expanded_dict)

        return ret

    def _expand_dict(self, dict_info):
        """
        将网络冻结配置解析出的字典平铺化
        :param dict_info: 平铺前的配置字典
        :return: 平铺后的配置字典
        """
        common_prefix_dict = dict()

        for key_item, val_item in dict_info.items():
            if key_item is None:
                logger.error('find [none] key from [freeze] config in model config file, '
                             'config is ignored, check model config file.')
                continue

            if val_item is None:
                logger.error('attribute of key: [%s] is none, config is ignored, check model config file.',
                             str(key_item))
                continue

            if isinstance(val_item, dict):
                val_item = self._expand_dict(val_item)
                common_prefix_dict.update(self.get_prefix_dict(dict_info=val_item, prefix_str=str(key_item)))
            else:
                if str(key_item) in common_prefix_dict:
                    logger.warning('find duplicate key from [freeze] part in model config file, check settings.')
                else:
                    common_prefix_dict.update({str(key_item): [val_item for val_item in str(val_item).split(' ')]})

        return common_prefix_dict
