#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import os

from tk.src.utils.constants import EMPTY_STRING, BLACKLIST_CHARACTERS, BASE_WHITELIST_CHARACTERS, MAX_FILE_MB_SIZE, \
    MB_SIZE, ENTRANCE_TYPE, MIN_MODE, MAX_MODE, GB_SIZE
from tk.src.utils.io_utils import is_link_path
from tk.src.utils.entrance_monitor import entrance_monitor
from tk.src.utils.exceptions import FileOversizeError, LinkPathError, LowDiskFreeSizeRiskError
from tk.src.log.log import logger


def get_real_path(path):
    """
    获取给定路径对应的真实路径

    :param path: 给定路径
    :return: 给定路径对应真实路径
    """
    if path is None or path == EMPTY_STRING:
        logger.error('detect invalid path when getting real path.')
        raise ValueError

    return os.path.realpath(path)


class OptionBase:
    def __init__(self, option_name, option_value):
        """
        构造方法
        :param option_name: 入参名称
        :param option_value: 入参值
        """
        if option_name is None or option_name == EMPTY_STRING:
            logger.error('option_name is none or empty.')
            raise ValueError

        if option_value is None or option_value == EMPTY_STRING:
            logger.error('option_value is none or empty.')
            raise ValueError

        self.option_name = option_name
        self.option_value = option_value

    def _is_file_path(self):
        """
        判断路径是否是一个文件

        :return: 是否是一个文件
        """
        return os.path.isfile(self.option_value)

    def _is_dir_path(self):
        """
        判断路径是否是一个文件夹

        :return: 是否是一个文件夹
        """
        return os.path.isdir(self.option_value)


class PathLengthCheckParam:
    def __init__(self, path_min_limit, path_max_limit, file_min_limit, file_max_limit):
        """
        :param path_min_limit: 路径最小长度约束
        :param path_max_limit: 路径最大长度约束
        :param file_min_limit: 文件名最小长度约束
        :param file_max_limit: 文件名最大长度约束
        """
        self.path_min_limit = path_min_limit
        self.path_max_limit = path_max_limit
        self.file_min_limit = file_min_limit
        self.file_max_limit = file_max_limit


class PathContentCheckParam:
    def __init__(self, base_whitelist_mode, extra_whitelist):
        """
        :param base_whitelist_mode: 路径基础白名单模式
        :param extra_whitelist: 路径额外字符白名单
        """
        self.base_whitelist_mode = base_whitelist_mode
        self.extra_whitelist = extra_whitelist


class InteractionByEntrance(OptionBase):
    def __init__(self, option_name, option_value, notice_msg, notice_accept_msg, exception_type):
        """
        根据使用入口(CLI/SDK)执行不同的交互逻辑
        Args:
            option_name: 参数名称
            option_value: 参数值
            notice_msg: 通知消息
            notice_accept_msg: 用户接受通知消息
            exception_type: 异常类型
        """
        super(InteractionByEntrance, self).__init__(option_name, option_value)
        self.notice_msg = notice_msg
        self.notice_accept_msg = notice_accept_msg
        self.exception_type = exception_type

    def interact_by_entrance(self, force_quit, quiet):
        """
        根据不同的入口(CLI/SDK), 进行不同类型权限校验交互
        :param force_quit: 触发校验异常时，是否强制结束进程
        :param quiet: 是否启用安静模式
        """
        entrance_type = entrance_monitor.get_value(ENTRANCE_TYPE)

        if entrance_type == 'CLI':
            try:
                self._interact_by_cli(force_quit, quiet)
            except self.exception_type as ex:
                raise ex
        elif entrance_type == 'SDK':
            try:
                self._interact_by_sdk(force_quit)
            except self.exception_type as ex:
                raise ex
        else:
            logger.error('invalid entrance_type.')
            raise ValueError

    def _interact_by_cli(self, force_quit, quiet):
        """
        CLI场景下的交互方式
        :param force_quit: 是否强制终止请求
        :param quiet: 是否启动安静模式
        """
        if quiet:
            if not force_quit:
                logger.warning(self.notice_msg)
            else:
                logger.error(self.notice_msg)
                raise self.exception_type
        else:
            ans = input(self.notice_msg + ' would you like to continue? (y/n)')
            if str(ans).lower() != 'y':
                logger.info('current command is cancelled.')
                raise self.exception_type
            logger.info(self.notice_accept_msg)

    def _interact_by_sdk(self, force_quit):
        """
        SDK场景下的交互方式
        :param force_quit: 是否强制终止请求
        """
        if force_quit:
            logger.error(self.notice_msg)
            raise self.exception_type
        else:
            logger.warning(self.notice_msg)


class PathContentBlacklistCharactersCheck(OptionBase):
    def __init__(self, option_name, option_value):
        super(PathContentBlacklistCharactersCheck, self).__init__(option_name, option_value)
        try:
            self._check()
        except ValueError as ex:
            raise ex

    def _check(self):
        """
        路径内容黑名单字符校验
        """
        self.option_value = str(self.option_value).strip()

        for item in BLACKLIST_CHARACTERS:
            if item in self.option_value:
                logger.error('param: [%s] contains invalid character(s), check settings.', self.option_name)
                raise ValueError


class AbsolutePathCheck(OptionBase):
    def __init__(self, option_name, option_value):
        super(AbsolutePathCheck, self).__init__(option_name, option_value)
        try:
            self._check()
        except ValueError as ex:
            raise ex

    def _check(self):
        """
        绝对路径校验
        """
        if not os.path.isabs(self.option_value):
            logger.error('File/Path: [%s] is not an absolute path.', self.option_name)
            raise ValueError


class PathExistCheck(OptionBase):
    def __init__(self, option_name, option_value):
        super(PathExistCheck, self).__init__(option_name, option_value)
        try:
            self._check()
        except FileNotFoundError as ex:
            raise ex

    def _check(self):
        """
        路径真实性校验
        """
        if not os.path.exists(self.option_value):
            logger.error('File/Path: [%s] does not exist.', self.option_name)
            raise FileNotFoundError


class LinkPathCheck(OptionBase):
    def __init__(self, option_name, option_value):
        super(LinkPathCheck, self).__init__(option_name, option_value)
        try:
            self._check()
        except LinkPathError as ex:
            raise ex

    def _check(self):
        """
        路径软链接校验
        """
        if is_link_path(self.option_value):
            logger.error('Path: [%s] is a link path.', self.option_name)
            raise LinkPathError


class PathContentLengthCheck(OptionBase):
    def __init__(self, option_name, option_value, path_min_limit, path_max_limit, file_min_limit, file_max_limit):
        super(PathContentLengthCheck, self).__init__(option_name, option_value)
        try:
            self._check(path_min_limit, path_max_limit, file_min_limit, file_max_limit)
        except ValueError as ex:
            raise ex

    def _check(self, path_min_limit, path_max_limit, file_min_limit, file_max_limit):
        """
        内容长度校验

        :param path_min_limit: 路径最小长度, 默认为0
        :param path_max_limit: 路径最大长度
        :param file_min_limit: 文件最小长度
        :param file_max_limit: 文件最大长度
        """
        if not self._path_length_check_item(path_min_limit=path_min_limit, path_max_limit=path_max_limit):
            raise ValueError

        if self._is_file_path():
            if not self._file_length_check_item(file_min_limit=file_min_limit, file_max_limit=file_max_limit):
                raise ValueError

    def _path_length_check_item(self, path_min_limit, path_max_limit):
        """
        路径粒度长度校验

        :param path_min_limit: 路径最小长度限制, 默认值为0
        :param path_max_limit: 路径最大长度限制
        :return: 路径粒度长度是否合规
        """
        path_min_limit = 0 if path_min_limit is None else path_min_limit

        if path_min_limit is not None and path_min_limit < 0:
            logger.error('path_min_limit should be non-negative integer.')
            return False

        if path_max_limit is not None and path_max_limit < 0:
            logger.error('path_max_limit should be non-negative integer.')
            return False

        if path_min_limit is not None and path_max_limit is not None and path_min_limit > path_max_limit:
            logger.error('path_min_limit should be less than or equal to path_max_limit.')
            return False

        if path_min_limit is not None and len(self.option_value) < path_min_limit:
            logger.error('path length of param: [%s] is invalid.', self.option_name)
            return False

        if path_max_limit is not None and len(self.option_value) > path_max_limit:
            logger.error('path length of param: [%s] is invalid.', self.option_name)
            return False

        return True

    def _file_length_check_item(self, file_min_limit, file_max_limit):
        """
        文件名粒度长度校验

        :param file_min_limit: 文件名最小长度限制, 默认值为0
        :param file_max_limit: 文件名最大长度限制
        :return: 文件名粒度长度是否合规
        """
        file_name = os.path.basename(self.option_value)
        file_min_limit = 0 if file_min_limit is None else file_min_limit

        if file_min_limit is not None and file_min_limit < 0:
            logger.error('file_min_limit should be non-negative integer.')
            return False

        if file_max_limit is not None and file_max_limit < 0:
            logger.error('file_max_limit should be non-negative integer.')
            return False

        if file_min_limit is not None and file_max_limit is not None and file_min_limit > file_max_limit:
            logger.error('file_min_limit should be less than or equal to file_max_limit.')
            return False

        if file_min_limit is not None and len(file_name) < file_min_limit:
            logger.error('file name in path of param: [%s] is invalid.', self.option_name)
            return False

        if file_max_limit is not None and len(file_name) > file_max_limit:
            logger.error('file name in path of param: [%s] is invalid.', self.option_name)
            return False

        return True


class PathContentCharacterCheck(OptionBase):
    def __init__(self, option_name, option_value, base_whitelist_mode, extra_whitelist):
        super(PathContentCharacterCheck, self).__init__(option_name, option_value)
        try:
            self._check(base_whitelist_mode, extra_whitelist)
        except ValueError as ex:
            raise ex

    @staticmethod
    def get_base_whitelist_by_mode(base_whitelist_mode):
        """
        根据base_whitelist_mode获得对应字符粒度参数校验基础白名单

        :param base_whitelist_mode: 模式类型，包括全大写/全小写/数字/大小写字母/大小写字母和数字
        :return: 基础白名单字符列表
        """
        if base_whitelist_mode not in BASE_WHITELIST_CHARACTERS.keys():
            logger.error('base_whitelist_mode is wrong, only support %s', list(BASE_WHITELIST_CHARACTERS.keys()))
            raise ValueError

        return BASE_WHITELIST_CHARACTERS.get(base_whitelist_mode)

    def _check(self, base_whitelist_mode, extra_whitelist):
        """
        内容字符级校验

        :param base_whitelist_mode: 基础白名单模式
        :param extra_whitelist: 额外补充白名单字符
        """
        try:
            base_whitelist_mode = self.get_base_whitelist_by_mode(base_whitelist_mode)
        except ValueError as ex:
            logger.error('error occurred when getting base whitelist by base_whitelist_mode.')
            raise ex

        extra_whitelist = [] if extra_whitelist is None else extra_whitelist
        whitelist = base_whitelist_mode + extra_whitelist

        for val in self.option_value:
            if val not in whitelist:
                logger.error('invalid character(s) in param: [%s], check settings.', self.option_name)
                raise ValueError


class PathGranularityCheck(OptionBase):
    def __init__(self, option_name, option_value, path_including_file):
        super(PathGranularityCheck, self).__init__(option_name, option_value)
        try:
            self._check(path_including_file)
        except ValueError as ex:
            raise ex

    def _check(self, path_including_file):
        """
        路径粒度校验(文件夹/文件)
        """
        status = True

        if path_including_file is not None:
            status = self._is_file_path() if path_including_file else self._is_dir_path()

        if not status:
            logger.error('param: [%s] should be a %s path.',
                         self.option_name, 'file' if path_including_file else 'dir')
            raise ValueError


class PathRightEscalationCheck(OptionBase):
    def __init__(self, option_name, option_value, mode, force_quit, quiet):
        super(PathRightEscalationCheck, self).__init__(option_name, option_value)
        try:
            self._check(mode, force_quit, quiet)
        except (PermissionError, ValueError) as ex:
            raise ex

    @staticmethod
    def mode_property_check(mode):
        """
        mode属性合法性检查, 返回合法的路径权限
        :param mode: 路径要求的权限范围, 要求必须是字符串类型, 包含3位数字, 数字范围[0,7], 例如'755'
        :return 路径权限值
        """
        try:
            mode = str(mode)
        except TypeError as ex:
            logger.error('invalid param: [mode] for mode_property_check.')
            raise ex

        if len(mode) != 3:
            logger.error('invalid param: [mode] for mode_property_check.')
            raise ValueError

        for pri in mode:
            try:
                pri = int(pri)
            except TypeError as ex:
                logger.error('invalid param: [mode] for mode_property_check.')
                raise ex

            if pri < MIN_MODE or pri > MAX_MODE:
                logger.error('invalid param: [mode] for mode_property_check.')
                raise ValueError

        ret = (int(mode[0]), int(mode[1]), int(mode[2]))

        return ret

    def _check(self, mode, force_quit, quiet):
        """
        权限提升校验
        :param mode:路径权限约束
        :param force_quit: 发现权限提升问题是否强制退出
        """
        # 路径属主一致性校验
        is_legal_mode = True

        try:
            self._path_owner_check()
        except (PermissionError, KeyError) as ex:
            is_legal_mode = False

        # 路径权限范围校验
        try:
            self._path_mode_check(mode)
        except (PermissionError, ValueError, TypeError) as ex:
            is_legal_mode = False

        if not is_legal_mode:
            notice_msg = f'param: [{self.option_name}] may have risk of rights escalation ' \
                         f'(owner of path from param: [{self.option_name}] is not current login user, ' \
                         f'or other users have unnecessary permissions of path from param: [{self.option_name}]).'

            notice_accept_msg = 'current login user has accepted the risk of rights escalation.'

            interaction_op = InteractionByEntrance(option_name=self.option_name,
                                                   option_value=self.option_value,
                                                   notice_msg=notice_msg,
                                                   notice_accept_msg=notice_accept_msg,
                                                   exception_type=PermissionError)
            try:
                interaction_op.interact_by_entrance(force_quit=force_quit, quiet=quiet)
            except (PermissionError, ValueError) as ex:
                raise ex

    def _path_owner_check(self):
        """
        路径属主一致性校验, 判断路径属主和当前用户是否一致
        """
        path_owner = os.stat(self.option_value).st_uid

        current_login_user = os.geteuid()

        if path_owner != current_login_user:
            raise PermissionError

    def _path_mode_check(self, mode):
        """
        路径权限校验
        :param mode: 路径要求的权限范围
        """
        try:
            required_mode = self.mode_property_check(mode)
        except (ValueError, TypeError) as ex:
            raise ex

        actual_mode = self._get_path_mode()

        mode_size = len(required_mode)

        for idx in range(mode_size):
            if required_mode[idx] | actual_mode[idx] != required_mode[idx]:
                raise PermissionError

    def _get_path_mode(self):
        """
        获得当前路径对应的权限, 分用户权限/同组权限/其他权限, 使用十进制表示
        :return: tuple元素, (用户权限, 同组权限, 其他权限)
        """
        mode = oct(os.stat(self.option_value).st_mode)[-3:]
        ret = (int(mode[0]), int(mode[1]), int(mode[2]))
        return ret


class FileSizeCheck(OptionBase):
    def __init__(self, option_name, option_value, path_including_file):
        super(FileSizeCheck, self).__init__(option_name, option_value)
        try:
            self._check(path_including_file)
        except FileOversizeError as ex:
            raise ex

    def _check(self, path_including_file):
        """
        文件类型路径过大文件校验
        """
        if path_including_file:
            size = os.stat(self.option_value).st_size / MB_SIZE
            if size > MAX_FILE_MB_SIZE:
                logger.error('File: [%s] is too large.', self.option_name)
                raise FileOversizeError


class DiskFreeSpaceCheck(OptionBase):
    def __init__(self, option_name, option_value, free_space_limit, force_quit, quiet):
        super(DiskFreeSpaceCheck, self).__init__(option_name, option_value)
        self.free_space_limit = free_space_limit
        try:
            self._check(force_quit, quiet)
        except (PermissionError, ValueError) as ex:
            raise ex

    def _check(self, force_quit, quiet):
        """
        校验参数对应路径对应的磁盘空间是否低于最小空间大小限制
        Args:
            force_quit: 是否强制退出
            quiet: 是否安静模式
        """
        info = os.statvfs(self.option_value)

        free_size = info.f_bsize * info.f_bavail

        logger.info(
            f'disk where param {self.option_name} is located has {round(free_size / GB_SIZE, 2)} GB free space.')

        if free_size <= self.free_space_limit:
            notice_msg = f'free space of disk where param [{self.option_name}] is located is no greater than 1 GB, ' \
                         f'there is risk of disk exhaustion.'

            notice_accept_msg = 'current login user has accepted the risk of disk exhaustion.'

            interaction_op = InteractionByEntrance(option_name=self.option_name,
                                                   option_value=self.option_value,
                                                   notice_msg=notice_msg,
                                                   notice_accept_msg=notice_accept_msg,
                                                   exception_type=LowDiskFreeSizeRiskError)
            try:
                interaction_op.interact_by_entrance(force_quit=force_quit, quiet=quiet)
            except (LowDiskFreeSizeRiskError, ValueError) as ex:
                raise ex
