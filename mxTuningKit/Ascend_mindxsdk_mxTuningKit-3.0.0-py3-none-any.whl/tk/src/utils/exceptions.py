#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

from tk.src.utils.constants import EMPTY_STRING


class FileOversizeError(Exception):
    def __init__(self, error_info=None):
        super(FileOversizeError, self).__init__()
        self.error_info = error_info

    def __str__(self):
        return self.error_info if self.error_info else EMPTY_STRING


class LinkPathError(Exception):
    def __init__(self, error_info=None):
        super(LinkPathError, self).__init__()
        self.error_info = error_info

    def __str__(self):
        return self.error_info if self.error_info else EMPTY_STRING


class MakeDirError(Exception):
    def __init__(self, error_info=None):
        super(MakeDirError, self).__init__()
        self.error_info = error_info

    def __str__(self):
        return self.error_info if self.error_info else EMPTY_STRING


class SubprocessError(Exception):
    def __init__(self, error_info=None):
        super(SubprocessError, self).__init__()
        self.error_info = error_info

    def __str__(self):
        return self.error_info if self.error_info else EMPTY_STRING


class LowDiskFreeSizeRiskError(Exception):
    def __init__(self, error_info=None):
        super(LowDiskFreeSizeRiskError, self).__init__()
        self.error_info = error_info

    def __str__(self):
        return self.error_info if self.error_info else EMPTY_STRING
