#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import os
import signal
import time
import uuid
import multiprocessing

from pathlib import Path

from tk.src.log.log import logger, logger_without_std, record_operation_and_service_info_log
from tk.src.utils.constants import OUTPUT_PATH_RANDOM_DIR_MODE, TIME_MONITOR_SLEEP_TIME, SECONDS_PER_HOUR, \
    HOURS_PER_DAY, TK_DEFINED_PARAM_NAME, INVALID_CUSTOM_PARAM_KEY_PREFIX, INVALID_CUSTOM_PARAM_VAL_PREFIX
from tk.src.security.param_check.model_config_check_utils import ModelConfigCheck
from tk.src.utils.exceptions import MakeDirError


def monitor_process_rsp_code(task_name, task_process, timeout=None):
    """
    含超时机制的子进程监测器, 并获取子进程结束状态码
    :param task_name: 任务名称
    :param task_process: 待监听进程
    :param timeout: 超时时间(秒数)
    """
    timeout_monitor_process = None

    # 启动异步进程做超时监听
    if timeout is not None:
        timeout_monitor_process = multiprocessing.Process(target=timeout_monitor,
                                                          args=(task_name, task_process, timeout))
        timeout_monitor_process.start()

    # 持续监听子进程标准输出管道, 捕捉管道内容并落盘
    while task_process.poll() is None:
        process_log = str(task_process.stdout.readline().decode('utf-8')).rstrip()
        if process_log:
            logger.info(process_log, extra={'Model': True})

    # 子进程正常退出时, 如超时监听进程未结束, 结束超时监听
    if timeout is not None and timeout_monitor_process is not None and timeout_monitor_process.is_alive():
        timeout_monitor_process.terminate()

    return task_process.poll()


def timeout_monitor(task_name, task_process, timeout):
    """
    超时监听, 超时后终止被监听进程
    :param task_name: 任务名称
    :param task_process: 被监听进程
    :param timeout: 超时时间(秒数)
    """
    begin_time = time.time()
    while True:
        if time.time() - begin_time > timeout + 1:
            days = int(timeout // SECONDS_PER_HOUR // HOURS_PER_DAY)
            hours = int((timeout // SECONDS_PER_HOUR) % HOURS_PER_DAY)

            logger.info('task exceeds the time limit, it is forcibly terminated [%ddays %dhours].', days, hours)
            record_operation_and_service_info_log('%s failed because of time limit.', task_name)
            task_process.kill()
            task_process.terminate()

            # 避免子进程无法全部结束, 向同进程组进程发送结束信号
            try:
                os.killpg(os.getpgid(os.getpid()), signal.SIGTERM)
            except Exception as ex:
                logger_without_std('task exceeds the time limit, it is forcibly terminated [%ddays %dhours].', days,
                                   hours)
                break

        time.sleep(TIME_MONITOR_SLEEP_TIME)


def create_output_path_subdir_with_uuid(output_path):
    """
    在output_path下生成包含uuid随机片段的子文件夹名称
    :param output_path: 入参output_path值
    """
    uuid_name = str(uuid.uuid4()).replace('-', '')
    random_dir = f'tk_{uuid_name}'.upper()
    full_output_path = os.path.join(output_path, random_dir).replace('\\', '/')

    while os.path.exists(full_output_path):
        uuid_name = str(uuid.uuid4()).replace('-', '')
        random_dir = f'tk_{uuid_name}'.upper()
        full_output_path = os.path.join(output_path, random_dir).replace('\\', '/')

    try:
        os.makedirs(full_output_path, exist_ok=True, mode=OUTPUT_PATH_RANDOM_DIR_MODE)
    except Exception as ex:
        logger.error('failed to create directory in [output_path].')
        raise MakeDirError from ex

    logger.info(f'create output folder successfully, output folder: {random_dir}')
    return full_output_path


def params_config_check_item(content, option_object):
    """
    model config自定义参数内容黑名单校验及参数拼装
    :param content: 待校验内容
    :param option_object: 参数对象
    """
    if 'params' in content.keys():
        params_config = content.get('params')

        if params_config is None:
            logger.error('[params] attribute in model config file is empty, check settings.')
            raise ValueError

        params_check = ModelConfigCheck(params_config=params_config, freeze_config=None)
        params_check.check()
        if not params_check.is_valid:
            raise ValueError

        # tk对外提供的参数, 不允许通过model_config配置文件二次配置, 且配置键值对需避免不合法前缀
        try:
            filter_params_config(option_object, params_config)
        except ValueError as ex:
            raise ex


def filter_params_config(option_object, params_config):
    """
    model config自定义参数前缀合法性检查及参数拼接
    :param option_object: 选项对象
    :param params_config: 自定义超参数字典
    """
    for param in params_config.items():
        if param[0] in TK_DEFINED_PARAM_NAME:
            logger.warning(f'find duplicate key [{param[0]}] from [params] part in model config file, check settings.')
            continue

        # 自定义超参数不合法前缀校验
        custom_param_key = str(param[0])
        custom_param_val = str(param[1])
        if custom_param_key.startswith(INVALID_CUSTOM_PARAM_KEY_PREFIX) or custom_param_val.startswith(
                INVALID_CUSTOM_PARAM_VAL_PREFIX):
            logger.error('invalid character in [params] part from model config file.')
            raise ValueError

        option_object.command_params.extend([f'--{custom_param_key}', custom_param_val])


def freeze_config_check_item(content, option_object, model_config_path):
    """
    model config网络冻结参数内容黑名单校验及参数拼装
    :param content: 待校验内容
    :param option_object: 参数对象
    :param model_config_path: model config配置文件路径
    """
    if 'freeze' in content.keys():
        freeze_config = content.get('freeze')

        if freeze_config is None:
            logger.error('[freeze] attribute in model config file is empty, check settings.')
            raise ValueError

        freeze_check = ModelConfigCheck(params_config=None, freeze_config=freeze_config)
        freeze_check.check()
        if not freeze_check.is_valid:
            raise ValueError

        option_object.command_params.extend(['--advanced_config', model_config_path])


def config_key_check_item(content, config_keys):
    if not isinstance(config_keys, tuple):
        config_keys = (config_keys,)

    try:
        for key_item in content.keys():
            if key_item not in config_keys:
                logger.error('invalid config in model config file, only support %s',
                             config_keys)
                raise ValueError
    except AttributeError as ex:
        logger.error('invalid key in model config file.')
        raise ex


def check_in_out_loop(param_dict):
    """
    用于判断输入、输出路径是否存在回环可能
    Args:
        param_dict: 输入参数集合
    """
    # 从参数集合中提取输出路径
    output_path = Path(param_dict.get('output_path'))

    # 从参数集合中提取输入路径
    input_path_list = [Path(param_dict.get('data_path'))]
    if param_dict.get('pretrained_model_path') is not None:
        input_path_list.append(Path(param_dict.get('pretrained_model_path')))
    if param_dict.get('ckpt_path') is not None:
        input_path_list.append(Path(param_dict.get('ckpt_path')))

    # 判断输入路径、输出径是否相等 或 输出路径是否是输入路径的子路径；如果是，则存在回环路径的可能
    for input_path in input_path_list:
        if (output_path == input_path) or (input_path in output_path.parents):
            raise ValueError
