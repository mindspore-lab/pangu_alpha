#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

import sys
import click

from tk.src.option_decorators import finetune_options, evaluate_options, infer_options
from tk.src.utils.constants import ENTRANCE_TYPE, ABNORMAL_EXIT_CODE, NORMAL_EXIT_CODE
from tk.src.task.finetune.finetune_task import FinetuneTask
from tk.src.task.evaluate.evaluate_task import EvaluateTask
from tk.src.task.infer.infer_task import InferTask
from tk.src.utils.entrance_monitor import entrance_monitor
from tk.src.log.log import logger, set_logger_property, log_valid_exception, \
    record_operation_and_service_info_log


def cli_wrapper():
    """
    CLI侧入口
    """
    entrance_monitor.set_value(ENTRANCE_TYPE, 'CLI')
    # 设置日志内容发起端标识
    set_logger_property("CLI")

    try:
        cli()
    except (Exception, SystemExit) as ex:
        log_valid_exception(ex)
        if isinstance(ex, Exception) or (isinstance(ex, SystemExit) and str(ex) != str(NORMAL_EXIT_CODE)):
            logger.warning('exception or artificial cancellation occurred, see above info for detail error message.')
            sys.exit(ABNORMAL_EXIT_CODE)


@click.group()
def cli():
    pass


@cli.command()
@finetune_options()
def finetune(*args, **kwargs):
    """
    command line finetune entrance
    """
    record_operation_and_service_info_log('start finetune.')

    try:
        finetune_task = FinetuneTask(*args, **kwargs)
    except (Exception, KeyboardInterrupt) as ex:
        raise ex

    try:
        return finetune_task.start()
    except (Exception, KeyboardInterrupt) as ex:
        raise ex


@cli.command()
@infer_options()
def infer(*args, **kwargs):
    """
    command line infer entrance
    """
    record_operation_and_service_info_log('start infer.')

    try:
        infer_task = InferTask(*args, **kwargs)
    except (Exception, KeyboardInterrupt) as ex:
        raise ex

    try:
        return infer_task.start()
    except (Exception, KeyboardInterrupt) as ex:
        raise ex


@cli.command()
@evaluate_options()
def evaluate(*args, **kwargs):
    """
    command line evaluate entrance
    """
    record_operation_and_service_info_log('start evaluate.')

    try:
        evaluate_task = EvaluateTask(*args, **kwargs)
    except (Exception, KeyboardInterrupt) as ex:
        raise ex

    try:
        return evaluate_task.start()
    except (Exception, KeyboardInterrupt) as ex:
        raise ex
