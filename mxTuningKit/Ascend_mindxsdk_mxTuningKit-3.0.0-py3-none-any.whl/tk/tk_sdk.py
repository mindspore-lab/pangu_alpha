#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2010-2022. All rights reserved.

from tk.tk_main import cli
from tk.src.utils.constants import ENTRANCE_TYPE, EMPTY_STRING, ARG_NAMES
from tk.src.utils.entrance_monitor import entrance_monitor
from tk.src.log.log import logger, log_valid_exception, set_logger_property

entrance_monitor.set_value(ENTRANCE_TYPE, 'SDK')
set_logger_property('SDK')


def finetune(*args, **kwargs):
    """
    SDK侧微调功能入口

    :param args: 参数args
    :param kwargs: 参数kwargs
    :return: 任务执行结果
    """
    try:
        commands = commands_generator('finetune', args, kwargs)
        return cli.main(commands, standalone_mode=False)
    except Exception as ex:
        log_valid_exception(ex)
        logger.warning('exception or artificial cancellation occurred, see above info for detail error message.')
        return False


def evaluate(*args, **kwargs):
    """
    SDK侧评估功能入口

    :param args: 参数args
    :param kwargs: 参数kwargs
    :return: 任务执行结果
    """
    try:
        commands = commands_generator('evaluate', args, kwargs)
        return cli.main(commands, standalone_mode=False)
    except Exception as ex:
        log_valid_exception(ex)
        logger.warning('exception or artificial cancellation occurred, see above info for detail error message.')
        return EMPTY_STRING


def infer(*args, **kwargs):
    """
    SDK侧推理功能入口

    :param args: 参数args
    :param kwargs: 参数kwargs
    :return: 任务执行结果
    """
    try:
        commands = commands_generator('infer', args, kwargs)
        return cli.main(commands, standalone_mode=False)
    except Exception as ex:
        log_valid_exception(ex)
        logger.warning('exception or artificial cancellation occurred, see above info for detail error message.')
        return EMPTY_STRING


def commands_generator(header, args, kwargs):
    """
    命令行生成器, 组装命令行参数

    :param header: 待执行功能
    :param args: 待组装args参数
    :param kwargs: 待组装kwargs参数
    :return: 组装后命令
    """
    output = []

    # 避免恶意传入过多参数导致下标越界
    args_length = min(len(args), len(ARG_NAMES.get(header)))

    for idx in range(args_length):
        output.append('--{}'.format(ARG_NAMES.get(header)[idx]))
        output.append('{}'.format(args[idx]))

    for key_item, val_item in kwargs.items():
        # 安静模式仅允许CLI场景使用, SDK场景不允许配置该值, 给予错误警告
        if str(key_item) == 'quiet':
            logger.error('param [quiet] is not supported by SDK.')
            raise ValueError
        else:
            output.append('--{}'.format(key_item))
            output.append('{}'.format(val_item))

    return [header] + output
